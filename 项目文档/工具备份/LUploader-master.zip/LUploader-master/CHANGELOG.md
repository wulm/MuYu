## LUploader v1.1 - 修改于2016年3月23日
* 增加quality压缩比参数，使插件更灵活
* 修复多选上传功能bug（感谢网友[jerry-he](https://github.com/jerry-he)提供bug）
 
## LUploader - 修改于2016年3月16日
* LUploader体验版诞生
