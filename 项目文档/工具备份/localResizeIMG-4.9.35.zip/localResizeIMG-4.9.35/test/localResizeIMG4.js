document.querySelector('input[type=file]').addEventListener('change', function () {
    var that = this;
    lrz(that.files[0], {
        width: 800
    })
        .then(function (rst) {
			var imgView = document.getElementById("imgView");
			img = new Image(),
                div = document.createElement('div'),
                p = document.createElement('p'),
                sourceSize = toFixed2(that.files[0].size / 1024),
                resultSize = toFixed2(rst.fileLen / 1024),
                scale = parseInt(100 - (resultSize / sourceSize * 100));
			imgView.innerHTML = "";//先清空原先数值
			 p.style.fontSize = 13 + 'px';
			 p.innerHTML      = '源文件大小：<span>' +
                sourceSize + 'KB' +
                '</span> <br />' +
                '压缩后大小：<span>' +
                resultSize + 'KB (省' + scale + '%)' +
                '</span> ';
			 div.className = '';		
			 div.appendChild(img);
			 div.appendChild(p);
			img.onload = function () {
                document.querySelector('#imgView').appendChild(div);
            };
            img.src = rst.base64;
           	document.getElementById("fileBase64").value = rst.base64;
            return rst;
        });
});

function toFixed2 (num) {
    return parseFloat(+num.toFixed(2));
}